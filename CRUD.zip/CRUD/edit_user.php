<?php
include('db.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch user data
    $sql = "SELECT * FROM users WHERE id = $id";
    $result = $conn->query($sql);
    $user = $result->fetch_assoc();

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Get the updated values from the form
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];

        // Update the user data
        $update_sql = "UPDATE users SET name = '$name', email = '$email', phone = '$phone' WHERE id = $id";
        if ($conn->query($update_sql) === TRUE) {
            header("Location: index.php"); // Redirect to the user list
            exit();
        } else {
            echo "Error: " . $update_sql . "<br>" . $conn->error;
        }
    }
} else {
    echo "User not found!";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>

    <!-- Bootstrap CSS (via CDN) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        /* Optional custom styles */
        .form-container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <div class="container my-5">
        <h2 class="text-center mb-4">Edit User</h2>

        <!-- Form container -->
        <div class="form-container">
            <form method="post" action="" id="editForm">
                <div class="mb-3">
                    <label for="name" class="form-label">Name:</label>
                    <input type="text" class="form-control" name="name" id="name" value="<?php echo $user['name']; ?>" required>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Email:</label>
                    <input type="email" class="form-control" name="email" id="email" value="<?php echo $user['email']; ?>" required>
                </div>

                <div class="mb-3">
                    <label for="phone" class="form-label">Phone:</label>
                    <input type="text" class="form-control" name="phone" id="phone" value="<?php echo $user['phone']; ?>" required>
                </div>

                <div class="mb-3 text-center">
                    <button type="submit" class="btn btn-primary">Update User</button>
                </div>
            </form>

            <div class="text-center">
                <a href="index.php" class="btn btn-secondary">Back to User List</a>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS & Popper.js (via CDN) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

    <!-- Custom JavaScript for form validation -->
    <script>
        // Optional: Form validation to check for empty fields
        document.getElementById('editForm').addEventListener('submit', function(event) {
            var name = document.getElementById('name').value;
            var email = document.getElementById('email').value;
            var phone = document.getElementById('phone').value;

            // Simple validation for empty fields
            if (!name || !email || !phone) {
                alert('All fields are required!');
                event.preventDefault(); // Prevent form submission
            }
        });
    </script>
</body>
</html>
