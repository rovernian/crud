<?php
$host = "localhost";
$user = "root"; // Your MySQL username
$password = ""; // Your MySQL password
$db = "crud_app"; // The database we just created

// Create connection
$conn = new mysqli($host, $user, $password, $db);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
